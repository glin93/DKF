import pandas as pd


single_gen = pd.read_csv('./mem-generate.txt',sep='\t',skiprows=0,names=['m_gen','target'])
multi_gen = pd.read_csv('./multi-mem-generate.txt',sep='\t',skiprows=0,names=['multi_gen','target'])