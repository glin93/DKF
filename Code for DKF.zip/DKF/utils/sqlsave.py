from sqlalchemy import Column, String, create_engine, Integer, Float, DateTime, ForeignKey,JSON
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from datetime import *
import uuid

"""


create database using
    create database models;
"""


# 创建对象的基类:
Base = declarative_base()
# 定义User对象:
class ModelSaver(Base):
    # 表的名字:
    __tablename__ = 'commit'
    # 表的结构:
    id = Column(Integer, primary_key=True)
    id_uuid = Column(String(64))  # 每个实验都一个唯一的编号
    name = Column(String(64))  # the runs models
    para = Column(JSON)
    dataset = Column(String(64))
    hiddensize = Column(Integer)  # hidden size
    kb_layers = Column(Integer)
    memory_layers = Column(Integer)
    dropout = Column(Float)
    commit_time = Column(DateTime, default=datetime.now)

    load_limits = Column(Integer)

    best_metrics= Column(JSON)

    addition = Column(String(100))


class RunerResults(Base):
    # 表的名字:
    __tablename__ = 'runs'
    # metrics
    id = Column(Integer, primary_key=True)
    model_path = Column(String(100))  # 模型的具体路径
    id_uuid = Column(String(64))  # 在具体的一次运行中,每轮都会保存模型
    epochs = Column(Float)
    commit_time = Column(DateTime, default=datetime.now)
    bleu = Column(Float)
    f1 = Column(Float)
    f1_wet = Column(Float)
    f1_sch = Column(Float)
    f1_nav = Column(Float)


class DBstore(object):

    def __init__(self, **kwargs):
        self.dbsession = self._get_session()
        print('DB successfully connected')
        self.uuid = str(uuid.uuid4())

        # commit experiments
        self.commit_experiments(self.uuid, **kwargs)

    def exits(self):
        print('DB close session')
        self.dbsession.close()

    def commit_experiments(self, uuid, **kwargs):
        """write the paramter to the commit model
            The input should be a dict , including hidden size ,memory layers, kb_layers, dropout rate, additional \
            information
        """
        assert type(kwargs) == dict
        name = kwargs.get('name', '')
        dataset = kwargs.get('dataset','')
        hidden_size = kwargs.get('hidden_size', -1)
        dropout_rate = kwargs.get('dropout_rate', -1)
        layers = kwargs.get('layers', -1)
        kb_layers = kwargs.get('kb_layers', -1)

        para= kwargs.get('para',{})


        new_model = ModelSaver(id_uuid=uuid, name=name, hiddensize=hidden_size, kb_layers=kb_layers,
                               memory_layers=layers, dataset=dataset,para=para,\
                               dropout=dropout_rate)

        self.dbsession.add(new_model)

        self.dbsession.commit()

    def commit_runs(self, **kwargs):
        """
            model_path = Column(String(100))# 模型的具体路径
            id_uuid = Column(String(64))  # 在具体的一次运行中,每轮都会保存模型
            epochs = Column(Float)
            commit_time = Column(DateTime, default=datetime.now)
            bleu = Column(Float)
            f1 = Column(Float)
            f1_wet = Column(Float)
            f1_sch = Column(Float)
            f1_nav = Column(Float)
            acc_avg = Column(Float)
            dia_acc = Column(Float)
        :param uuid:
        :param kwargs:
        :return:
        """
        assert type(kwargs) == dict
        model_path = kwargs.get('model_path', '')
        epochs = kwargs.get('epochs', -1)
        bleu = kwargs.get('bleu', -1)
        f1 = kwargs.get('f1', -1)
        f1_wet = kwargs.get('f1_wet', -1)
        f1_sch = kwargs.get('f1_sch', -1)
        f1_nav = kwargs.get('f1_nav', -1)
        runs_record = RunerResults(id_uuid=self.uuid, model_path=model_path, epochs=epochs, bleu=float(bleu), f1=float(f1), \
                                   f1_wet=float(f1_wet), f1_nav=float(f1_nav), f1_sch=float(f1_sch))

        self.dbsession.add(runs_record)
        self.dbsession.commit()

    @classmethod
    def _get_session(cls):
        # 初始化数据库连接:
        engine = create_engine('mysql+mysqlconnector://ksce:123456@10.15.62.15:3306/models')
        #engine = create_engine('sqlite:///memory.db', echo=True)

        Base.metadata.create_all(engine)
        # 创建DBSession类型:
        DBSession = sessionmaker(bind=engine)

        return DBSession()


# Addition support for argvs
def get_parameters(argvs):
    """Return the corespending """


    name = argvs.get('name', '')
    hidden_size = argvs.get('hidden_size', -1)
    dropout_rate = argvs.get('dropout_rate', -1)
    layers = argvs.get('layers', -1)
    kb_layers = argvs.get('kb_layers', -1)

    collected = dict(name=name,hidden_size=hidden_size,dropout_rate=dropout_rate,layers=layers,\
                     kb_layers=kb_layers)

    return collected




if __name__ == '__main__':

    writer = DBstore()
    para = dict()

    writer.commit_runs(**para)
    writer.commit_runs()
    writer.commit_runs()

    writer.exits()
