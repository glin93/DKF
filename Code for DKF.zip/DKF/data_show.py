import numpy as np
import logging
from tqdm import tqdm

from utils.config import *
from models.enc_vanilla import *
from models.enc_Luong import *
from models.enc_PTRUNK import *
from models.Mem2Seq import *

BLEU = False
from utils.utils_kvr_multi_mem import *
# if (args['decoder'] == "Mem2Seq"):
#     if args['dataset']=='kvr':
#         from utils.utils_kvr_mem2seq import *
#         BLEU = True
#     elif args['dataset']=='babi':
#         from utils.utils_babi_mem2seq import *
#     else:
#         print("You need to provide the --dataset information")
# else:
#     if args['dataset']=='kvr':
#         from utils.utils_kvr import *
#         BLEU = True
#     elif args['dataset']=='babi':
#         from utils.utils_babi import *
#     else:
#         print("You need to provide the --dataset information")

# Configure models
avg_best,cnt,acc = 0.0,0,0.0
cnt_1 = 0
### LOAD DATA
train, dev, test, testOOV, lang, max_len, max_r = prepare_data_seq(args['task'], batch_size=int(args['batch']))

for batch in train:
    print(len(batch))
    inputs = batch[0].tolist()

    for sentenc in inputs:
        strm= ''
        for word in sentenc:
            strm +=  lang.index2word[word[0]]

        print(strm)


