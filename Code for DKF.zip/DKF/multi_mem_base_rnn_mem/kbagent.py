import numpy as np
import random
import json
import os
import torch
import torch.nn as nn


class _QNet(nn.Module):
    def __init__(self, state_size: int, action_size: int):
        super(_QNet, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(state_size, 256),
            nn.PReLU(),
            nn.Linear(256, action_size)
        )

    def forward(self, state):
        return self.fc(state)


class KBAgent(object):
    def __init__(self, 
                state_size: int, 
                action_size: int, 
                epsilon: float = 0.90,
                batch_size: int = 64,
                max_capacity: int = 10000,
                learnig_rate: float = 0.00025):
        super(KBAgent, self).__init__()
        self._state_size = state_size
        self._action_size = action_size
        self._epsilon = epsilon
        self._history = []
        self._step = 0
        self._gamma = 1.0
        self._target_step_iter = 128
        self._batch_size = batch_size
        self._max_capacity = max_capacity
        self._capacity_pos = 0
        self._eval_net, self._target_net = self._init_net()
        self._loss_fn = nn.MSELoss()
        self._optimizer = torch.optim.RMSprop(self._eval_net.parameters())

        self.max_score = 0
        self.total_score = 0
        self.epoch = 1

    def _init_net(self):
        eval_net = _QNet(self._state_size, self._action_size)
        target_net = _QNet(self._state_size, self._action_size)

        if torch.cuda.is_available():
            eval_net = eval_net.cuda()
            target_net = target_net.cuda()

        return eval_net, target_net

    def store_transition(self, state, action, new_state, reward):
        state = list(state)
        new_state = list(new_state)
        for i in range(len(state)):
            if len(self._history) < self._max_capacity:
                self._history.append(None)
            self._history[self._capacity_pos % self._max_capacity] = [state[i].tolist(), action, new_state[i].tolist(), reward]
            self._capacity_pos = (self._capacity_pos + 1) % self._max_capacity
        self._step += 1

    def act(self, state):
        if random.random() < self._epsilon:
            q_value = self._eval_net(state).clone().detach()
            action = int(q_value.argmax(-1)[0])
        else:
            action = random.randint(0, self._action_size - 1)

        return action

    def update(self, writer):
        if self._step != 0 and self._step % self._target_step_iter == 0:
            self._target_net.load_state_dict(self._eval_net.state_dict())
        else:
            return

        sample_memory = random.sample(self._history, self._batch_size)
        # states: (batch_size, state_size), actions: (batch_size, 1), new_states: (batch_size, 3), rewards: (batch_size, 1)
        states = torch.tensor([s[0] for s in sample_memory]).cuda()
        actions = torch.tensor([s[1] for s in sample_memory]).cuda()
        new_states = torch.tensor([s[2] for s in sample_memory]).cuda()
        rewards = torch.tensor([s[3] for s in sample_memory]).cuda()

        q_eval = self._eval_net(states).gather(1, actions.unsqueeze(1))
        q_next = self._target_net(new_states).detach().max(-1)[0].unsqueeze(1)
        q_target = rewards.unsqueeze(1) + self._gamma * q_next

        loss = self._loss_fn(q_eval, q_target)
        writer.add_scalar("Loss/loss_kbagent", loss.item())
        self._optimizer.zero_grad()
        loss.backward()
        self._optimizer.step()
