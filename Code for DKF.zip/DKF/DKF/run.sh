#!/bin/bash
set -e

# runs bash run.sh 0 16
cuda=$1
bsz=$2
echo "cuda device:$1"
echo "batch size:$2"
echo "In kvr dataset"

for hidden in 256 128
do
	flag=1
    for dr in 0.5 0.4 0.3 0.2 0.1
    do
        if [ $hidden -eq 128 ] && [ $flag -ne 1 ]
        then
            continue
        fi
		flag=`expr $flag + 1`
        CUDA_VISIBLE_DEVICES=$cuda python multi_mem_train.py -lr=0.001 -layer=3 -kb-layer=3 -hdd=$hidden -dr=$dr -dec=Mem2Seq -embeddingsize=256  -bsz=$bsz -ds=kvr -t=  --load-limits 10000 -model-name rnn_mem -serverip=http://127.0.0.1  -enbirnn -debirnn  -addition-name test_model
    done
done