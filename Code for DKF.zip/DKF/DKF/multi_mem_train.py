import numpy as np
import logging
from tqdm import tqdm
import sys
from sklearn.metrics import f1_score
from utils.config import *
from multi_mem_base_rnn_mem.multi_memory import computeF1
# from utils.measures import wer, moses_multi_bleu
from nltk.translate.bleu_score import corpus_bleu


def get_bleu_score(hyp:list, ref: list, lowercase=True):
    hyp = [x.lower().split() for x in hyp]
    ref = [[x.lower().split()] for x in ref]
    bleu_score = corpus_bleu(ref, hyp)
    return float(bleu_score)

# import data
if args['dataset'] == 'kvr':
    from utils.utils_kvr_multi_mem import *

    BLEU = True
elif args['dataset'] == 'babi':
    from utils.utils_babi_multi_mem import *
    BLEU =False
else:
    print("You need to provide the --dataset information")


# Configure models
cnt = 0
bleu_best, f1_best, f1_cal_best, f1_wet_best, f1_nav_best, dia_best, acc_best = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
bleu_, f1_, f1_cal_, f1_wet_,  f1_nav_, dia_, acc_ = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0



if  args['model_name'] == 'rnn_mem':

    print('Using rnn in memory')
    from multi_mem_base_rnn_mem.multi_memory import Mem2Seq

    train, dev, test, testOOV, lang, max_len, max_r = prepare_data_seq(args['task'], batch_size=int(args['batch']))

    model = Mem2Seq(int(args['hidden']), max_len, max_r, lang, args['path'], args['task'],
                    lr=float(args['learn']),
                    n_layers=int(args['layer']),
                    dropout=float(args['drop']),
                    unk_mask=bool(int(args['unk_mask'])),
                    kb_mem_hop=int(args['kb_layer']),
                    env_name='multi'+args['dataset']+args['task']+'hop' + str(args['layer'])+'KB'+args['kb_layer']+'_limits{}'.format(args['load_limits']) +'_dr{}hdd{}'.format(args['drop'],args['hidden']) +args['addition_name'],
                    debug_host_ip=args['serverip'],
                    debirnn=args['debirnn'],
                    enbirnn=args['enbirnn']
                    )
else:
    raise RuntimeError('No defined parameters')


# 下面开始训练过程,dynamic的数据读取有些不一样,所以需要判断一下

print('Using bleu:{}'.format(BLEU))
for epoch in range(int(args['epoch'])):
    logging.info("Epoch:{}".format(epoch))
    # Run the train function
    from tqdm import tqdm
    pbar = tqdm(enumerate(train), total=len(train))

    for i, data in pbar:

        s, a = model.train_batch(
            input_batches=data[0],
            input_lengths=data[1],
            target_batches=data[2],
            target_lengths=data[3],
            target_index=data[4],
            target_gate=data[5],
            batch_size=len(data[1]),
            clip=10,
            teacher_forcing_ratio=0.5,
            conv_seqs=data[-6],
            conv_lengths=data[-5],
            kb_seqs=data[-4],
            kb_lengths=data[-3],
            kb_target_index=data[-2],
            kb_plain=data[-1],
            reset=i == 0
        )

        with torch.no_grad():
            words = model.evaluate_batch(batch_size=len(data[1]),
                                                    input_batches=data[0],
                                                    input_lengths=data[1],
                                                    target_batches=data[2],
                                                    target_lengths=data[3],
                                                    target_index=data[4],
                                                    target_gate=data[5],
                                                    src_plain=data[6],
                                                    conv_seqs=data[-6],
                                                    conv_lengths=data[-5],
                                                    kb_seqs=data[-4],
                                                    kb_lengths=data[-3],
                                                    kb_target_index=data[-2],
                                                    kb_plain=data[-1],
                                                    step=0,
                                                    Analyse=False)

        acc = 0
        w = 0
        temp_gen = []
        dialog_acc_dict = {}
        microF1_PRED, microF1_PRED_cal, microF1_PRED_nav, microF1_PRED_wet = [], [], [], []
        microF1_TRUE, microF1_TRUE_cal, microF1_TRUE_nav, microF1_TRUE_wet = [], [], [], []
        ref = []
        hyp = []
        ref_s = ""
        hyp_s = ""
        
        for i, row in enumerate(np.transpose(words)):
            st = ''
            for e in row:
                if e == '<EOS>':
                    break
                else:
                    st += e + ' '
            if len(str(st.lstrip().rstrip())) == 0:
                st = '.'
            temp_gen.append(st)
            correct = data[7][i]
            ### compute F1 SCORE
            if args['dataset'] == 'kvr':
                # TODO:Check this
                f1_true, f1_pred = computeF1(data[8][i], st.lstrip().rstrip(), correct.lstrip().rstrip())
                microF1_TRUE += f1_true
                microF1_PRED += f1_pred
                f1_true, f1_pred = computeF1(data[9][i], st.lstrip().rstrip(), correct.lstrip().rstrip())
                microF1_TRUE_cal += f1_true
                microF1_PRED_cal += f1_pred
                f1_true, f1_pred = computeF1(data[10][i], st.lstrip().rstrip(), correct.lstrip().rstrip())
                microF1_TRUE_nav += f1_true
                microF1_PRED_nav += f1_pred
                f1_true, f1_pred = computeF1(data[11][i], st.lstrip().rstrip(), correct.lstrip().rstrip())
                microF1_TRUE_wet += f1_true
                microF1_PRED_wet += f1_pred
            elif args['dataset'] == 'babi' and int(args['task']) == 6:
                f1_true, f1_pred = computeF1(data[-6][i], st.lstrip().rstrip(), correct.lstrip().rstrip())
                microF1_TRUE += f1_true
                microF1_PRED += f1_pred
            if args['dataset'] == 'babi':
                if data[-5][i] not in dialog_acc_dict.keys():
                    dialog_acc_dict[data[-5][i]] = []
                if (correct.lstrip().rstrip() == st.lstrip().rstrip()):
                    acc += 1
                    dialog_acc_dict[data[-5][i]].append(1)
                else:
                    dialog_acc_dict[data[-5][i]].append(0)
            else:
                if (correct.lstrip().rstrip() == st.lstrip().rstrip()):
                    acc += 1

            ref.append(str(correct.lstrip().rstrip()))
            hyp.append(str(st.lstrip().rstrip()))
            ref_s += str(correct.lstrip().rstrip()) + "\n"
            hyp_s += str(st.lstrip().rstrip()) + "\n"
        
        if args['dataset'] == 'babi':
            dia_acc = 0
            for k in dialog_acc_dict.keys():
                if len(dialog_acc_dict[k]) == sum(dialog_acc_dict[k]): # whole dialog
                    dia_acc += 1
            reward = dia_acc * 1.0
        if args['dataset'] == 'kvr':
            f1 = f1_score(microF1_TRUE, microF1_PRED, average='micro')
            f1_cal = f1_score(microF1_TRUE_cal, microF1_PRED_cal, average='micro')
            f1_wet = f1_score(microF1_TRUE_wet, microF1_PRED_wet, average='micro')
            f1_nav = f1_score(microF1_TRUE_nav, microF1_PRED_nav, average='micro')
            reward = (f1 + f1_cal + f1_nav + f1_wet) / 4
        elif args['dataset'] == 'babi' and int(args['task']) == 6:
            f1 = f1_score(microF1_TRUE, microF1_PRED, average='micro')
            # reward = f1 * 1.0
        # Report Bleu score
        assert len(hyp[0]) != 0
        bleu_score = get_bleu_score(hyp, ref, lowercase=True)
        # bleu_score = moses_multi_bleu(np.array(hyp), np.array(ref), lowercase=True)
        if args['dataset'] == 'kvr' or int(args['task']) == 6:
            # reward = (reward + bleu_score) / 2
            reward = bleu_score
        
        model.writer.add_scalar('Metrics/reward', reward)
        model.kb_agent.store_transition(s, a, torch.ones_like(s), reward)
        model.kb_agent.update(model.writer)

        pbar.set_description(model.print_loss())
    

    model.writer.add_scalar('Loss/loss_avg', model.print_loss_avg, epoch)
    model.writer.add_scalar('Loss/loss_kb', model.print_loss_kb, epoch)
    model.writer.add_scalar('Loss/loss_memory', model.print_loss_memory, epoch)
    model.writer.add_scalar('Loss/loss_vocab', model.print_loss_vocabulary, epoch)


    if ((epoch + 1) % int(args['evalp']) == 0):
        bleu_, f1_, f1_cal_, f1_wet_,  f1_nav_, dia_, acc_ = model.evaluate(dev, bleu_best, f1_best, f1_cal_best, f1_wet_best, f1_nav_best, dia_best, acc_best, epoch=epoch, BLEU= BLEU,type='dev')
        if args['dataset']=='babi' and int(args['task'])<=5:
            # test oov datasets
            print('testing on oov')
            _, _, _, _, _, _, _ = model.evaluate(testOOV, bleu_best, f1_best, f1_cal_best, f1_wet_best, f1_nav_best, dia_best, acc_best,epoch=epoch,BLEU=BLEU,type='test')
        if 'Mem2Seq' in args['decoder']:
            if args['dataset']=='babi' and int(args['task'])<=5:
                metric_avg = (dia_ + acc_) / 2
            if args['dataset']=='babi' and int(args['task'])==6:
                metric_avg = (bleu_/100 + f1_) / 2
            if args['dataset']=='kvr':
                metric_avg = (bleu_/100 + (f1_ + f1_cal_ + f1_wet_ + f1_nav_) / 4) / 2
            model.scheduler.step(metric_avg)
        if (bleu_ >= bleu_best):
            bleu_best = bleu_
        if (f1_ >= f1_best):
            f1_best = f1_
        if (f1_cal_ >= f1_cal_best):
            f1_cal_best = f1_cal_
        if (f1_wet_ >= f1_wet_best):
            f1_wet_best = f1_wet_
        if (f1_nav_ >= f1_nav_best):
            f1_nav_best = f1_nav_
        if (dia_ >= dia_best):
            dia_best = dia_
        if (acc_ >= acc_best):
            acc_best = acc_ 


model.writer.close()

