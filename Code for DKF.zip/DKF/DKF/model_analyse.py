"""
本文件是用来分析训练好的模型的生成质量的
设置
"""

import warnings
from utils.config import *
BLEU = False
if args['model_name'] != 'rnn_mem':
    print('Using origin dataset reading function')
    if (args['decoder'] == "Mem2Seq"):
        if args['dataset'] == 'kvr':
            from utils.utils_kvr_mem2seq import *
            BLEU = True
        elif args['dataset'] == 'babi':
            from utils.utils_babi_mem2seq import *
        else:
            print("You need to provide the --dataset information")
    else:
        if args['dataset'] == 'kvr':
            from utils.utils_kvr import *

            BLEU = True
        elif args['dataset'] == 'babi':
            from utils.utils_babi import *
        else:
            print("You need to provide the --dataset information")
else:
    if args['dataset'] == 'kvr':
        from utils.utils_kvr_multi_mem import *
        print('Using multi-mem dataset reading function:{}'.format("kvr"))
        BLEU = True
    elif args['dataset'] == 'babi':
        print('Using multi-mem dataset reading function:{}'.format("babi"))
        from utils.utils_babi_multi_mem import *
    else:
        print("You need to provide the --dataset information")



# Configure models
avg_best, cnt, acc = 0.0, 0, 0.0
cnt_1 = 0

train, dev, test, testOOV, lang, max_len, max_r = prepare_data_seq(args['task'], batch_size=int(args['batch']),
                                                                   shuffle=True)

if args['model_name'] != 'rnn_mem':

    if args['decoder'] == "Mem2Seq":
        warnings.warn('Start to run the origin mem2seq model')
        from models.Mem2Seq import  Mem2Seq
        model =Mem2Seq(hidden_size=int(args['hidden']),
                                           max_len=max_len,
                                           max_r=max_r,
                                           lang=lang,
                                           path=args['path'],
                                           task=args['task'],
                                           lr=float(args['learn']),
                                           n_layers=int(args['layer']),
                                           dropout=float(args['drop']),
                                           unk_mask=bool(int(args['unk_mask'])),
                                           env_name='singlemem' + args['dataset'] + args['task'] + 'hop_' + str(
                                               args['layer']) + '_dr{}_hdd{}'.format(args['drop'], args['hidden']),
                                           debug_host_ip=args['serverip']
                                           )
    else:
        from models.enc_vanilla import *
        from models.enc_Luong import *
        from models.enc_PTRUNK import *

        args['path'] = 'save/Luong_KB-KVR/HDD512DR0.3L1lr0.0001LuongSeqToSeq10.26'
        warnings.warn('Start to run the origin seq2seq {} model'.format(args['decoder']))

        model = globals()[args['decoder']](embedding_size =int(args['embeddingsize']),
                                           hidden_size=int(args['hidden']),
                                           max_len= max_len,
                                           max_r=max_r,
                                           lang=lang,
                                           path=args['path'],
                                           task=args['task'],
                                           lr=float(args['learn']),
                                           n_layers=int(args['layer']),
                                           dropout=float(args['drop']),
                                           env_name=args['decoder'] + args['dataset'] + args['task'] + 'hop_' + str(
                                           args['layer']) + '_dr{}_hdd{}'.format(args['drop'], args['hidden']),
                                           debug_host_ip='http://127.0.0.1'
                                           )
        if getattr(model.encoder,'word_size',None) == None:
            warnings.warn("seq2seq model don't have attribute word size")
            model.encoder.word_size=int(args['hidden'])
            model.decoder.word_size=int(args['hidden'])
elif args['model_name'] == 'rnn_mem':
    warnings.warn('Start to run the multi-mem version')
    args['path'] = 'save/mem2seq-KVR/HDD256BSZ64DR0.4L3lr0.001BESTbleu_score_BEST2'
    print('Using rnn in memory,restoring from :{}'.format(args['path']))
    
    from multi_mem_base_rnn_mem.multi_memory import Mem2Seq
    model = Mem2Seq(int(args['hidden']), max_len, max_r, lang, args['path'], args['task'],
                    lr=float(args['learn']),
                    n_layers=int(args['layer']),
                    dropout=float(args['drop']),
                    unk_mask=bool(int(args['unk_mask'])),
                    kb_mem_hop=int(args['layer']),
                    env_name='multimemrnn_hop_' + str(args['layer'])+'_dr{}_hdd{}'.format(args['drop'],args['hidden']) +args['addition_name'],
                    debug_host_ip=args['serverip'],
                    enbirnn=args['enbirnn'],
                    debirnn=args['debirnn']
                    )
else:
    raise RuntimeError('Not defined model name')

print('Evaluating on the development dataset')

acc = model.evaluate(dev, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, epoch =121, BLEU=BLEU,Analyse=True,type='dev')





