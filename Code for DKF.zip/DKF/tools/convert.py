"""
将bAbI-5或者6的KB放到对话中的最前面

"""
import os
import argparse





def process_files(filepath,outputpath):
    print('Generate files from {} to {}'.format(filepath,outputpath))
    with open(filepath,'r')as src_fp:
        with open(outputpath,'w') as des_fp:
            buffer_kb,buffer_dialoge = [],[]
            for line in src_fp:
                line = line.strip()
                if line:
                    nid,line = line.split(' ',1)
                    if '\t' in line :
                        # 如有\t,说明是对话
                        buffer_dialoge.append(line)
                    else:
                        buffer_kb.append(line)
                else:
                    # 说明新的对话要开始了,将保存的结果进行输出
                    count = 1
                    if len(buffer_dialoge) !=0 :
                        for line in buffer_kb:
                            des_fp.write(str(count)+' '+line+'\n')
                            count+=1
                        for line in buffer_dialoge:
                            des_fp.write(str(count)+' '+line+'\n')
                            count+=1
                        des_fp.write('\n')
                    else:
                        print("dialoge,kb:",len(buffer_dialoge),len(buffer_kb))
                        raise RuntimeError()

                    # clear kb , history
                    buffer_kb.clear()
                    buffer_dialoge.clear()


if __name__ == '__main__':

    ## Get parameters
    parser = argparse.ArgumentParser(description='Seq_TO_Seq Dialogue bAbI')
    parser.add_argument('-task', '--task', help='the task of babi', required=True)
    args = vars(parser.parse_args())

    print('Start to process the babi task-{}'.format(args['task']))

    ## parameters ends

    home = os.path.expanduser("~")
    path = os.path.join('data')

    train_file = os.path.join(path, "dialog-bAbI-tasks", 'dialog-babi-task{}trn.txt'.format(args['task']))
    dev_file = os.path.join(path, "dialog-bAbI-tasks", 'dialog-babi-task{}dev.txt'.format(args['task']))
    test_file = os.path.join(path, 'dialog-bAbI-tasks', 'dialog-babi-task{}tst.txt'.format(args['task']))

    train_result = os.path.join(path, "dialog-bAbI-tasks", 'dialog-babi-task{}trnRP.txt'.format(args['task']))
    test_result = os.path.join(path, "dialog-bAbI-tasks", 'dialog-babi-task{}devRP.txt'.format(args['task']))
    dev_result = os.path.join(path, "dialog-bAbI-tasks", 'dialog-babi-task{}tstRP.txt'.format(args['task']))



    process_files(train_file,train_result)
    process_files(dev_file,dev_result)
    process_files(test_file,test_result)

